<?php

/**
 * ac_cred.inc.php: Secret Connection Credentials for a database class
 * @package Oracle
 */
/**
 * DB user name
 */
defined('SCHEMA') || define('SCHEMA', 'system');
/**
 * DB Password.
 *
 * Note: In practice keep database credentials out of directories
 * accessible to the web server.
 */
defined('PASSWORD') || define('PASSWORD', 'dhana');
/**
 * DB connection identifier
 */
defined('DATABASE') || define('DATABASE', 'localhost/XE:oradev');
/**
 * DB character set for returned data
 */
defined('CHARSET') || define('CHARSET', 'UTF8');
/**
 * Client Information text for DB tracing
 */
defined('CLIENT_INFO') || define('CLIENT_INFO', 'AnyCo Corp.');
?>