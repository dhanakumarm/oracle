BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE cart';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE cart (
  id number(10) NOT NULL,
  client_ip varchar2(20) NOT NULL,
  user_id number(10) NOT NULL,
  product_id number(10) NOT NULL,
  qty number(10) NOT NULL,
  PRIMARY KEY (id)
)  ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE cart_seq START WITH 16 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER cart_seq_tr
 BEFORE INSERT ON cart FOR EACH ROW
 WHEN (NEW.id IS NULL)
BEGIN
 SELECT cart_seq.NEXTVAL INTO :NEW.id FROM DUAL;
END;
/


BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE category_list';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE category_list (
  id number(10) NOT NULL,
  name clob NOT NULL,
  PRIMARY KEY (id)
)  ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE category_list_seq START WITH 7 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER category_list_seq_tr
 BEFORE INSERT ON category_list FOR EACH ROW
 WHEN (NEW.id IS NULL)
BEGIN
 SELECT category_list_seq.NEXTVAL INTO :NEW.id FROM DUAL;
END;
/


INSERT INTO category_list (id, name)
	 SELECT 1, 'Beverages' FROM dual UNION ALL 
	 SELECT 3, 'Best Sellers' FROM dual UNION ALL 
	 SELECT 4, 'Meals' FROM dual UNION ALL 
	 SELECT 5, 'Snacks' FROM dual UNION ALL 
	 SELECT 6, 'Dessert' FROM dual;

BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE orders';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE orders (
  id number(10) NOT NULL,
  name clob NOT NULL,
  address clob NOT NULL,
  mobile clob NOT NULL,
  email clob NOT NULL,
  status number(3) DEFAULT 0 NOT NULL,
  PRIMARY KEY (id)
)  ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE orders_seq START WITH 6 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER orders_seq_tr
 BEFORE INSERT ON orders FOR EACH ROW
 WHEN (NEW.id IS NULL)
BEGIN
 SELECT orders_seq.NEXTVAL INTO :NEW.id FROM DUAL;
END;
/


INSERT INTO orders (id, name, address, mobile, email, status)
	 SELECT 1, 'James Smith', 'adasdasd asdadasd', '4756463215', 'jsmith@sample.com', 1 FROM dual UNION ALL 
	 SELECT 2, 'James Smith', 'adasdasd asdadasd', '4756463215', 'jsmith@sample.com', 1 FROM dual UNION ALL 
	 SELECT 3, 'Camp Codes', '06106 Capitol Site, Brgy. Washington', '+639079373', 'admin@campcodes.com', 1 FROM dual UNION ALL 
	 SELECT 4, 'Camp Codes', '06106 Capitol Site, Brgy. Washington', '+639079373', 'admin@campcodes.com', 1 FROM dual UNION ALL 
	 SELECT 5, 'Camp Codes', '06106 Capitol Site, Brgy. Washington', '+639079373', 'admin@campcodes.com', 1 FROM dual;

BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE order_list';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE order_list (
  id number(10) NOT NULL,
  order_id number(10) NOT NULL,
  product_id number(10) NOT NULL,
  qty number(10) NOT NULL,
  PRIMARY KEY (id)
)  ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE order_list_seq START WITH 12 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER order_list_seq_tr
 BEFORE INSERT ON order_list FOR EACH ROW
 WHEN (NEW.id IS NULL)
BEGIN
 SELECT order_list_seq.NEXTVAL INTO :NEW.id FROM DUAL;
END;
/


INSERT INTO order_list (id, order_id, product_id, qty)
	 SELECT 1, 1, 3, 1 FROM dual UNION ALL 
	 SELECT 2, 1, 5, 1 FROM dual UNION ALL 
	 SELECT 3, 1, 3, 1 FROM dual UNION ALL 
	 SELECT 4, 1, 6, 3 FROM dual UNION ALL 
	 SELECT 5, 2, 1, 2 FROM dual UNION ALL 
	 SELECT 6, 3, 6, 2 FROM dual UNION ALL 
	 SELECT 7, 3, 7, 1 FROM dual UNION ALL 
	 SELECT 8, 4, 1, 1 FROM dual UNION ALL 
	 SELECT 9, 4, 4, 1 FROM dual UNION ALL 
	 SELECT 10, 5, 6, 2 FROM dual UNION ALL 
	 SELECT 11, 5, 1, 2 FROM dual;

BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE product_list';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE product_list (
  id number(10) NOT NULL,
  category_id number(10) NOT NULL,
  name varchar2(100) NOT NULL,
  description clob NOT NULL,
  price binary_double DEFAULT 0 NOT NULL,
  img_path clob NOT NULL,
  status number(3) DEFAULT 1 NOT NULL ,
  PRIMARY KEY (id)
)  ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE product_list_seq START WITH 8 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER product_list_seq_tr
 BEFORE INSERT ON product_list FOR EACH ROW
 WHEN (NEW.id IS NULL)
BEGIN
 SELECT product_list_seq.NEXTVAL INTO :NEW.id FROM DUAL;
END;
/

INSERT INTO product_list (id, category_id, name, description, price, img_path, status)
	 SELECT 1, 3, 'Diet Coke', 'In Can', 20, '1600652160_diet_coke.jpg', 1 FROM dual UNION ALL 
	 SELECT 3, 3, 'Lemon Iced Tea', 'Sample', 15, '1600652520_lemon iced tea.jpg', 1 FROM dual UNION ALL 
	 SELECT 4, 4, 'Chicken', 'Sample only', 150, '1600652880_chicken.jpg', 1 FROM dual UNION ALL 
	 SELECT 5, 3, 'Steak', 'Sample 2', 200, '1600652880_steak.jpg', 1 FROM dual UNION ALL 
	 SELECT 6, 3, 'Chicken2', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry�s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 250, '1600656600_checken2.jpg', 1 FROM dual UNION ALL 
	 SELECT 7, 6, 'Leche Plan', 'Leche Plan Big', 99, '1618937160_arrow.png', 1 FROM dual;

BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE system_settings';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE system_settings (
  id number(10) NOT NULL,
  name clob NOT NULL,
  email varchar2(200) NOT NULL,
  contact varchar2(20) NOT NULL,
  cover_img clob NOT NULL,
  about_content clob NOT NULL,
  PRIMARY KEY (id)
)  ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE system_settings_seq START WITH 2 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER system_settings_seq_tr
 BEFORE INSERT ON system_settings FOR EACH ROW
 WHEN (NEW.id IS NULL)
BEGIN
 SELECT system_settings_seq.NEXTVAL INTO :NEW.id FROM DUAL;
END;
/


INSERT INTO system_settings (id, name, email, contact, cover_img, about_content) VALUES
	(1, 'CampCodes - Online Food Ordering System', 'admin@admin.com', '+639079373999', '1600654680_photo-1504674900247-0877df9cc836.jpg', '&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;font-size:28px;background: transparent; position: relative;&quot;&gt;&lt;b style=&quot;margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; text-align: justify;&quot;&gt;NICE!&lt;/b&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;font-size:28px;background: transparent; position: relative;&quot;&gt;&lt;span style=&quot;color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; font-weight: 400; text-align: justify;&quot;&gt;&lt;br&gt;&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;text-align: center; background: transparent; position: relative;&quot;&gt;&lt;/p&gt;&lt;h2 style=&quot;font-size:28px;background: transparent; position: relative;&quot;&gt;Where does it come from?&lt;/h2&gt;&lt;p style=&quot;text-align: center; margin-bottom: 15px; padding: 0px; color: rgb(0, 0, 0); font-family: &amp;quot;Open Sans&amp;quot;, Arial, sans-serif; font-weight: 400;&quot;&gt;Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot; (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, &quot;Lorem ipsum dolor sit amet..&quot;, comes from a line in section 1.10.32.&lt;/p&gt;&lt;p&gt;&lt;/p&gt;');

BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE users';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE users (
  id number(10) NOT NULL,
  name varchar2(200) NOT NULL,
  username varchar2(100) NOT NULL,
  password varchar2(200) NOT NULL,
  type number(3) DEFAULT 2 NOT NULL ,
  PRIMARY KEY (id)
)  ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE users_seq START WITH 2 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER users_seq_tr
 BEFORE INSERT ON users FOR EACH ROW
 WHEN (NEW.id IS NULL)
BEGIN
 SELECT users_seq.NEXTVAL INTO :NEW.id FROM DUAL;
END;
/


INSERT INTO users (id, name, username, password, type) VALUES
	(1, 'Administrator', 'admin', 'admin123', 1);

BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE user_info';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE user_info (
  user_id number(10) NOT NULL,
  first_name varchar2(100) NOT NULL,
  last_name varchar2(100) NOT NULL,
  email varchar2(300) NOT NULL,
  password varchar2(300) NOT NULL,
  mobile varchar2(10) NOT NULL,
  address varchar2(300) NOT NULL,
  PRIMARY KEY (user_id)
)  ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE user_info_seq START WITH 3 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER user_info_seq_tr
 BEFORE INSERT ON user_info FOR EACH ROW
 WHEN (NEW.user_id IS NULL)
BEGIN
 SELECT user_info_seq.NEXTVAL INTO :NEW.user_id FROM DUAL;
END;
/


INSERT INTO user_info (user_id, first_name, last_name, email, password, mobile, address)
	 SELECT 1, 'James', 'Smith', 'jsmith@sample.com', '1254737c076cf867dc53d60a0364f38e', '4756463215', 'adasdasd asdadasd' FROM dual UNION ALL 
	 SELECT 2, 'Camp', 'Codes', 'admin@campcodes.com', '827ccb0eea8a706c4c34a16891f84e7b', '+639079373', '06106 Capitol Site, Brgy. Washington' FROM dual;



