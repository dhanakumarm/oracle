<?php

require('oracle.php');

defined('SCHEMA_NAME') || define('SCHEMA_NAME', 'oradev');

$conn        = new Db(SCHEMA_NAME, SCHEMA_NAME);
$SCHEMA_NAME = SCHEMA_NAME;
