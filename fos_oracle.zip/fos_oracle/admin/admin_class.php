<?php

session_start();

Class Action
{

    private $db;
    private $SCHEMA_NAME;

    public function __construct()
    {
        ob_start();
        //include 'db_connect.php';
        include_once('./../oracle_db_connect.php');
        $this->db          = $conn;
        $this->SCHEMA_NAME = $SCHEMA_NAME;
    }

    function __destruct()
    {
        //$this->db->close();
        ob_end_flush();
    }

    function login()
    {
        extract($_POST);
        $qry = $this->db->execFetchRow("SELECT * FROM $this->SCHEMA_NAME.users where username = '" . $username . "' and password = '" . $password . "' ", "admin_login");
        if (count($qry) > 0)
        {
            foreach ($qry as $key => $value)
            {
                $_SESSION['login_' . strtolower($key)] = $value;
            }
            return 1;
        }
        else
        {
            return 3;
        }
    }

    function login2()
    {
        extract($_POST);
        $qry = $this->db->execFetchRow("SELECT * FROM $this->SCHEMA_NAME.user_info where email = '" . $email . "' and password = '" . $password . "' ", "admin_login2");
        if (count($qry) > 0)
        {
            foreach ($qry as $key => $value)
            {
                $_SESSION['login_' . strtolower($key)] = $value;
            }
            $ip  = isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
            $sql = "UPDATE $this->SCHEMA_NAME.cart set user_id = '" . $_SESSION['login_user_id'] . "' where client_ip ='$ip' ";
            $this->db->execute($sql, "login2");
            return 1;
        }
        else
        {
            return 3;
        }
    }

    function logout()
    {
        session_destroy();
        foreach ($_SESSION as $key => $value)
        {
            unset($_SESSION[$key]);
        }
        header("location:login.php");
    }

    function logout2()
    {
        session_destroy();
        foreach ($_SESSION as $key => $value)
        {
            unset($_SESSION[$key]);
        }
        header("location:../index.php");
    }

    #### PENDING

    function save_user()
    {
        extract($_POST);
        $data = " name = '$name' ";
        $data .= ", username = '$username' ";
        $data .= ", password = '$password' ";
        $data .= ", type = '$type' ";
        if (empty($id))
        {
            $save = $this->db->query("INSERT INTO users set " . $data);
        }
        else
        {
            $save = $this->db->query("UPDATE users set " . $data . " where id = " . $id);
        }
        if ($save)
        {
            return 1;
        }
    }

    function signup()
    {
        extract($_POST);
        $data = "'$first_name'";
        $data .= ",'$last_name'";
        $data .= ",'$mobile'";
        $data .= ",'$address'";
        $data .= ",'$email' ";
        $data .= ",'" . ($password) . "'";
        $chk  = $this->db->execFetchAll("SELECT * FROM $this->SCHEMA_NAME.user_info where email = '$email' ", "admin_signup");
        if (count($chk) > 0)
        {
            return 2;
            exit;
        }
        $sql  = "INSERT INTO $this->SCHEMA_NAME.user_info(first_name,last_name,mobile,address,email,password) values (" . $data . ")";
        $save = $this->db->execute($sql, "signup");
        if (empty($save))
        {
            $login = $this->login2();
            return 1;
        }
    }

    function save_settings()
    {
        extract($_POST);
        $data  = " name = '$name' ";
        $data  .= ", email = '$email' ";
        $data  .= ", contact = '$contact' ";
        $data  .= ", about_content = '" . htmlentities(str_replace("'", "&#x2019;", $about)) . "' ";
        $fname = "t";
        if ($_FILES['img']['tmp_name'] != '')
        {
            $fname = strtotime(date('y-m-d H:i')) . '_' . $_FILES['img']['name'];
            $move  = move_uploaded_file($_FILES['img']['tmp_name'], '../assets/img/' . $fname);
            $data  .= ", cover_img = '$fname' ";
        }
        // echo "INSERT INTO system_settings set ".$data;
        $chk = $this->db->execFetchRow("SELECT * FROM $this->SCHEMA_NAME.system_settings", "admin_save_settings");

        if (count($chk) < 0)
        {
            $sql  = "UPDATE $this->SCHEMA_NAME.system_settings set " . $data . " where id =" . $chk['ID'];
            $save = $this->db->execute($sql, "update_save_settings");
        }
        else
        {
            $sql  = "INSERT INTO $this->SCHEMA_NAME.system_settings (name,email,contact,about_content,cover_img) values ('" . $name . "','" . $email . "','" . $contact . "','" . htmlentities(str_replace("'", "&#x2019;", $about)) . "','" . $fname . "')";
            $save = $this->db->execute($sql, "ins_save_settings");
        }
        if (empty($save))
        {
            $query = $this->db->execFetchRow("SELECT * FROM $this->SCHEMA_NAME.system_settings", "fetch_save_settings");
            foreach ($query as $key => $value)
            {
                $_SESSION['setting_' . strtolower($key)] = $value;
            }
            return 1;
        }
    }

    function save_category()
    {
        extract($_POST);
        $data = "'$name'";
        if (empty($id))
        {
            $sql  = "INSERT INTO $this->SCHEMA_NAME.category_list (name)  values (" . $data . ")";
            $save = $this->db->execute($sql, "admin_save_category");
        }
        else
        {
            $sql  = "UPDATE $this->SCHEMA_NAME.category_list set name=" . $data . " where id=" . $id;
            $save = $this->db->execute($sql, "admin_update_category");
        }
        if (empty($save))
            return 1;
    }

    function delete_category()
    {
        extract($_POST);
        $sql    = "DELETE FROM $this->SCHEMA_NAME.category_list where id = " . $id;
        $delete = $this->db->execute($sql, "confirm_order");
        if (empty($delete))
            return 1;
    }

    function save_menu()
    {
        extract($_POST);
        $fname  = "t";
        $data   = " name = '$name' ";
        $data   .= ", price = '$price' ";
        $data   .= ", category_id = '$category_id' ";
        $data   .= ", description = '$description' ";
        $status = "";
        if (isset($status) && $status == 'on')
        {
            $data   .= ", status = 1 ";
            $status = 1;
        }
        else
        {
            $data   .= ", status = 0 ";
            $status = 0;
        }

        if ($_FILES['img']['tmp_name'] != '')
        {
            $fname = strtotime(date('y-m-d H:i')) . '_' . $_FILES['img']['name'];
            $move  = move_uploaded_file($_FILES['img']['tmp_name'], '../assets/img/' . $fname);
            $data  .= ", img_path = '$fname' ";
        }
        if (empty($id))
        {
            $sql  = "INSERT INTO $this->SCHEMA_NAME.product_list (name,price,category_id,description,status,img_path) values ('" . $name . "','" . $price . "','" . $category_id . "','" . $description . "','" . $status . "','" . $fname . "')";
            $save = $this->db->execute($sql, "save_product_list");
        }
        else
        {
            $sql  = "UPDATE $this->SCHEMA_NAME.product_list set " . $data . " where id=" . $id;
            $save = $this->db->execute($sql, "update_product_list");
        }
        if (empty($save))
            return 1;
    }

    function delete_menu()
    {
        extract($_POST);
        $sql    = "DELETE FROM $this->SCHEMA_NAME.product_list where id = " . $id;
        $delete = $this->db->execute($sql, "delete_menu");
        if (empty($delete))
            return 1;
    }

    function add_to_cart()
    {
        extract($_POST);
        //$columns = ":product_id,";
        //$data[0] = array(":pid", $pid, -1);
        $ip     = 0;
        $userid = 0;
        $qty    = isset($qty) ? $qty : 1;
        //$columns .= ":qty,";
        //$data[1] = array(":qty", $qty, -1);       
        if (isset($_SESSION['login_user_id']))
        {
            //$columns .= ":user_id,";
            $userid = $_SESSION['login_user_id'];
            //$data[2] = array(":user_id", $_SESSION['login_user_id'], -1);
            //$data .= ", user_id = '" . $_SESSION['login_user_id'] . "' ";
        }
        else
        {
            //$columns .= ":client_ip,";
            $ip = isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
            //$data .= ", client_ip = '" . $ip . "' ";
            //$data[3] = array(":client_ip", $ip, -1);
        }
        //$columns = rtrim($columns, ",");
        $sql  = "INSERT INTO $this->SCHEMA_NAME.cart (client_ip, user_id, product_id, qty) VALUES ('$ip', '$userid', $pid, $qty)";
        $save = $this->db->execute($sql, "Insert Example");
        if ($save)
            return 1;
    }

    function get_cart_count()
    {
        extract($_POST);
        if (isset($_SESSION['login_user_id']))
        {
            $where = " where user_id = '" . $_SESSION['login_user_id'] . "'  ";
        }
        else
        {
            $ip    = isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR'];
            $where = " where client_ip = '$ip'  ";
        }
        $get = $this->db->execFetchRow("SELECT sum(qty) as cart FROM $this->SCHEMA_NAME.cart " . $where, "get_cart_count");

        if (isset($get['CART']) && $get['CART'] > 0)
        {
            return $get['CART'];
        }
        else
        {
            return '0';
        }
    }

    function update_cart_qty()
    {
        extract($_POST);
        $data = " qty = $qty ";
        $sql  = "UPDATE $this->SCHEMA_NAME.cart set " . $data . " where id = " . $id;
        $save = $this->db->execute($sql, "update_cart_qty");
        if (empty($save))
            return 1;
    }

    #### PENDING

    function save_order()
    {
        extract($_POST);
        $data      = " name = '" . $first_name . " " . $last_name . "' ";
        $data      .= ", address = '$address' ";
        $data      .= ", mobile = '$mobile' ";
        $data      .= ", email = '$email' ";
        $order_row = $this->db->execFetchRow("select max(id)+1 as id from $this->SCHEMA_NAME.orders", "admin_fetch_cart1");
        $order_id  = isset($order_row["ID"]) ? $order_row["ID"] : 0;
        $sql       = "INSERT INTO $this->SCHEMA_NAME.orders (id,name,address,mobile,email)values (" . $order_id . ", '" . $first_name . " " . $last_name . "','" . $address . "','" . $mobile . "','" . $email . "' )";
        $save      = $this->db->execute($sql, "save_order");
        if (empty($save))
        {
            $row = $this->db->execFetchRow("select max(id) as id from $this->SCHEMA_NAME.orders", "admin_fetch_cart2");
            $id  = isset($row["ID"]) ? $row["ID"] : 0;
            $qry = $this->db->execFetchAll("SELECT * FROM $this->SCHEMA_NAME.cart where user_id =" . $_SESSION['login_user_id'], "admin_fetch_cart");

            foreach ($qry as $key => $row)
            {
                $data  = " order_id = '$id' ";
                $data  .= ", product_id = '" . $row['PRODUCT_ID'] . "' ";
                $data  .= ", qty = '" . $row['QTY'] . "' ";
                $sql2  = "INSERT INTO $this->SCHEMA_NAME.order_list (order_id, product_id, qty) values ( '" . $id . "', '" . $row['PRODUCT_ID'] . "','" . $row['QTY'] . "') ";
                $save2 = $this->db->execute($sql2, "save_order2");
                if (empty($save2))
                {
                    $this->db->execute("DELETE FROM $this->SCHEMA_NAME.cart where id= " . $row['ID'], "delete");
                }
            }
            return 1;
        }
    }

    function confirm_order()
    {
        extract($_POST);
        $sql  = "UPDATE $this->SCHEMA_NAME.orders set status = 1 where id= " . $id;
        $save = $this->db->execute($sql, "confirm_order");
        if (empty($save))
            return 1;
    }

}
