<div class="container-fluid">
    <div class="card">
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>

                        <th>#</th>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $i   = 1;
                    //include 'db_connect.php';
                    include_once('./../oracle_db_connect.php');
                    $qry = $conn->execFetchAll("SELECT * FROM $SCHEMA_NAME.orders ", "orders");                  
                    foreach ($qry as $key => $value)
                    {
                        ?>
                        <tr>
                            <td><?php echo $i++ ?></td>
                            <td><?php echo $value['NAME'] ?></td>
                            <td><?php echo $value['ADDRESS'] ?></td>
                            <td><?php echo $value['EMAIL'] ?></td>
                            <td><?php echo $value['MOBILE'] ?></td>
                            <?php if ($value['STATUS'] == 1): ?>
                                <td class="text-center"><span class="badge badge-success">Confirmed</span></td>
                            <?php else: ?>
                                <td class="text-center"><span class="badge badge-secondary">For Verification</span></td>
                            <?php endif; ?>
                            <td>
                                <button class="btn btn-sm btn-primary view_order" data-id="<?php echo $value['ID'] ?>" >View Order</button>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<script>
    $('.view_order').click(function () {
        uni_modal('Order', 'view_order.php?id=' + $(this).attr('data-id'))
    })
</script>